using UnityEngine;
using UnityEngine.SceneManagement;

[DisallowMultipleComponent]
public class QuestGiverNPC : InteractableBase
{
    [Header("Quest")]
    [SerializeField] private QuestData quest;

    [Header("Identity")]
    [SerializeField] private string npcId;

    [Header("Dialogue")]
    [SerializeField] private DialogueData firstTimeDialogue;
    [SerializeField] private DialogueData inProgressDialogue;
    [SerializeField] private DialogueData turnInDialogue;
    [SerializeField] private DialogueData defaultDialogue;

    [Header("Debug")]
    [SerializeField] private bool resetFirstTimeOnPlay;

    private string firstTimeKey;
    private bool awaitingFirstTimeCompletion;
    private bool subscribed;

    protected override void Awake()
    {
        base.Awake();
        var scene = SceneManager.GetActiveScene().name;
        var id = string.IsNullOrWhiteSpace(npcId) ? gameObject.name : npcId;
        firstTimeKey = $"QuestGiverNPC.FirstTime.{scene}.{id}";

        if (resetFirstTimeOnPlay)
        {
            PlayerPrefs.DeleteKey(firstTimeKey);
        }
    }

    private void OnEnable()
    {
        subscribed = false;
        TrySubscribe();
    }

    private void OnDisable()
    {
        Unsubscribe();
    }

    private void Update()
    {
        if (!subscribed)
        {
            TrySubscribe();
        }
    }

    private void TrySubscribe()
    {
        if (subscribed) return;

        var ds = ResolveDialogueSystem();
        if (ds != null)
        {
            ds.OnDialogueEnded -= HandleDialogueEnded;
            ds.OnDialogueEnded += HandleDialogueEnded;
            subscribed = true;
        }
    }

    private void Unsubscribe()
    {
        if (!subscribed) return;

        var ds = ResolveDialogueSystem();
        if (ds != null)
        {
            ds.OnDialogueEnded -= HandleDialogueEnded;
        }

        subscribed = false;
    }

    private void HandleDialogueEnded()
    {
        if (!awaitingFirstTimeCompletion) return;

        awaitingFirstTimeCompletion = false;

        if (quest == null)
        {
            MarkFirstTimeConsumed();
            return;
        }

        if (QuestManager.Instance != null && QuestManager.Instance.IsAccepted(quest))
        {
            MarkFirstTimeConsumed();
        }
    }

    public override void Interact()
    {
        var ds = ResolveDialogueSystem();
        if (ds == null)
        {
            Debug.LogWarning($"QuestGiverNPC '{name}': DialogueSystem not found in loaded scenes.");
            return;
        }

        bool isFirstTime = !string.IsNullOrWhiteSpace(firstTimeKey) && PlayerPrefs.GetInt(firstTimeKey, 0) == 0;

        if (quest == null)
        {
            if (isFirstTime && firstTimeDialogue != null)
            {
                ds.StartDialogue(firstTimeDialogue, null);
                awaitingFirstTimeCompletion = true;
                return;
            }

            if (defaultDialogue != null)
            {
                ds.StartDialogue(defaultDialogue, null);
            }

            return;
        }

        if (QuestManager.Instance == null) return;

        bool accepted = QuestManager.Instance.IsAccepted(quest);

        if (!accepted)
        {
            if (isFirstTime && firstTimeDialogue != null)
            {
                ds.StartDialogue(firstTimeDialogue, null);
                awaitingFirstTimeCompletion = true;
                return;
            }

            if (defaultDialogue != null)
            {
                ds.StartDialogue(defaultDialogue, null);
            }

            return;
        }

        bool completed = QuestManager.Instance.IsCompleted(quest);
        bool ready = QuestManager.Instance.IsReadyToTurnIn(quest);

        if (completed)
        {
            if (defaultDialogue != null)
            {
                ds.StartDialogue(defaultDialogue, null);
            }

            return;
        }

        if (accepted && ready)
        {
            if (turnInDialogue != null)
            {
                ds.StartDialogue(turnInDialogue, null);
            }

            return;
        }

        if (accepted)
        {
            if (inProgressDialogue != null)
            {
                ds.StartDialogue(inProgressDialogue, null);
            }

            return;
        }

        if (defaultDialogue != null)
        {
            ds.StartDialogue(defaultDialogue, null);
        }
    }

    private static DialogueSystem ResolveDialogueSystem()
    {
        if (DialogueSystem.Instance != null) return DialogueSystem.Instance;

        var systems = FindObjectsByType<DialogueSystem>(FindObjectsInactive.Include);
        return systems != null && systems.Length > 0 ? systems[0] : null;
    }

    public override string GetInteractText()
    {
        if (quest == null)
        {
            bool hasDialogue = firstTimeDialogue != null || defaultDialogue != null || inProgressDialogue != null || turnInDialogue != null;
            return hasDialogue ? "Press " : string.Empty;
        }

        return "Press ";
    }

    public void MarkQuestAccepted()
    {
        MarkFirstTimeConsumed();
    }

    private void MarkFirstTimeConsumed()
    {
        if (!string.IsNullOrWhiteSpace(firstTimeKey))
        {
            PlayerPrefs.SetInt(firstTimeKey, 1);
        }

        var id = string.IsNullOrWhiteSpace(npcId) ? gameObject.name : npcId;
        if (QuestManager.Instance != null)
        {
            QuestManager.Instance.RegisterFirstTimeDialogueCompleted(id);
        }
    }
}
