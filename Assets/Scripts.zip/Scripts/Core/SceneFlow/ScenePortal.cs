using UnityEngine;
using System.Collections.Generic;
using System.Text;


[RequireComponent(typeof(Collider2D))]
public class ScenePortal : MonoBehaviour
{
    [Header("Destination")]
    [SerializeField] private string destinationScene;
    [SerializeField] private string destinationSpawnId = "Default";

    [Header("Behavior")]
    [SerializeField] private bool requirePlayerTag = true;

    [Header("Requirements")]
    [SerializeField] private List<ItemData> requiredItems = new List<ItemData>();
    [SerializeField, TextArea] private string missingItemsText = "You need to buy: {0}";
    [SerializeField] private string okText = "OK";
    [SerializeField] private bool completeObjectiveWhenRequirementsMet;
    [SerializeField] private string objectiveIdToComplete;

    [Header("Confirm")]
    [SerializeField] private bool requireConfirm = true;
    [SerializeField, TextArea] private string confirmText = "Do you want to travel?";
    [SerializeField] private string confirmYesText = "Yes";
    [SerializeField] private string confirmNoText = "No";

    [Header("Cooldown")]
    [SerializeField] private float portalCooldownSeconds = 1f;

    private float nextUseTime;
    private bool waitingForChoice;

    private void Reset()
    {
        var col = GetComponent<Collider2D>();
        if (col != null)
        {
            col.isTrigger = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (requirePlayerTag && !other.CompareTag("Player")) return;
        if (SceneFlowController.Instance == null) return;
        if (waitingForChoice) return;
        if (portalCooldownSeconds > 0f && Time.time < nextUseTime) return;

        if (!CheckItemRequirements(out string missingMessage))
        {
            ShowInfoDialogue(missingMessage);
            nextUseTime = Time.time + Mathf.Max(0f, portalCooldownSeconds);
            return;
        }

        // Requirements are met, so we can optionally complete a story objective even if the player
        // later cancels the confirm dialog. This avoids getting stuck with a "Buy supplies" task.
        if (completeObjectiveWhenRequirementsMet && StoryEventManager.Instance != null && !string.IsNullOrWhiteSpace(objectiveIdToComplete))
        {
            StoryEventManager.Instance.TryCompleteObjective(objectiveIdToComplete);
        }

        if (!requireConfirm)
        {
            UsePortal();
            return;
        }

        var ds = ResolveDialogueSystem();
        if (ds == null)
        {
            Debug.LogWarning("ScenePortal: requireConfirm is enabled but DialogueSystem was not found. Add DialogueSystem (and its UI) to your gameplay UI scene.");
            return;
        }

        if (ds.IsDialogueActive)
        {
            return;
        }

        waitingForChoice = true;
        DialogueData confirmData = CreateConfirmDialogue();

        ds.StartDialogue(confirmData, null, choice =>
        {
            bool shouldTeleport = choice != null && choice.choiceText == confirmYesText;
            if (shouldTeleport)
            {
                UsePortal();
            }

            waitingForChoice = false;
            nextUseTime = Time.time + Mathf.Max(0f, portalCooldownSeconds);

            if (confirmData != null)
            {
                Destroy(confirmData);
            }

            return true;
        });
    }

    private void UsePortal()
    {
        nextUseTime = Time.time + Mathf.Max(0f, portalCooldownSeconds);
        SceneFlowController.Instance.LoadGameplayScene(destinationScene, destinationSpawnId);
    }

    private bool CheckItemRequirements(out string message)
    {
        message = null;

        if (requiredItems == null || requiredItems.Count == 0) return true;
        if (InventorySystem.Instance == null)
        {
            message = "InventorySystem not found.";
            return false;
        }

        var missing = new List<string>();
        for (int i = 0; i < requiredItems.Count; i++)
        {
            var item = requiredItems[i];
            if (item == null) continue;

            if (InventorySystem.Instance.GetAmount(item) <= 0)
            {
                missing.Add(string.IsNullOrWhiteSpace(item.itemName) ? item.name : item.itemName);
            }
        }

        if (missing.Count == 0) return true;

        var sb = new StringBuilder();
        for (int i = 0; i < missing.Count; i++)
        {
            if (i > 0) sb.Append(", ");
            sb.Append(missing[i]);
        }

        string listText = sb.ToString();
        message = string.IsNullOrWhiteSpace(missingItemsText) ? listText : string.Format(missingItemsText, listText);
        return false;
    }

    private void ShowInfoDialogue(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;

        var ds = ResolveDialogueSystem();
        if (ds == null || ds.IsDialogueActive) return;

        var data = ScriptableObject.CreateInstance<DialogueData>();
        data.lines = new List<DialogueLine>(1)
        {
            new DialogueLine
            {
                text = text,
                choices = new List<DialogueChoice>(1)
                {
                    new DialogueChoice { choiceText = okText, type = ChoiceType.End }
                }
            }
        };

        ds.StartDialogue(data, null, _ =>
        {
            Destroy(data);
            return true;
        });
    }

    private static DialogueSystem ResolveDialogueSystem()
    {
        if (DialogueSystem.Instance != null) return DialogueSystem.Instance;

        var systems = Object.FindObjectsByType<DialogueSystem>(FindObjectsInactive.Include);
        return systems != null && systems.Length > 0 ? systems[0] : null;
    }

    private DialogueData CreateConfirmDialogue()
    {
        var data = ScriptableObject.CreateInstance<DialogueData>();
        data.lines = new List<DialogueLine>(1)
        {
            new DialogueLine
            {
                text = confirmText,
                choices = new List<DialogueChoice>(2)
                {
                    new DialogueChoice { choiceText = confirmYesText, type = ChoiceType.End },
                    new DialogueChoice { choiceText = confirmNoText, type = ChoiceType.End }
                }
            }
        };

        return data;
    }
}
