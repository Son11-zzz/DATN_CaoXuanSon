using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ShopUI : MonoBehaviour
{
    public static ShopUI Instance;

    [Header("Panel")]
    [SerializeField] private GameObject panel;

    [Header("Header")]
    [SerializeField] private TextMeshProUGUI shopNameText;
    [SerializeField] private TextMeshProUGUI moneyText;

    [Header("List")]
    [SerializeField] private Transform itemsRoot;
    [SerializeField] private GameObject itemRowPrefab;
    [SerializeField] private ScrollRect scrollRect;

    [Header("Info")]
    [SerializeField] private TextMeshProUGUI messageText;

    private ShopCatalog currentCatalog;

    private Coroutine refreshScrollRoutine;

    public bool IsOpen => panel != null && panel.activeSelf;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        if (panel == null)
        {
            panel = gameObject;
        }
    }

    private void Start()
    {
        Hide();
    }

    private void Update()
    {
        if (IsOpen && Input.GetKeyDown(KeyCode.Escape))
        {
            Hide();
        }

        if (IsOpen)
        {
            RefreshMoney();
        }
    }

    public void Show(ShopCatalog catalog)
    {
        currentCatalog = catalog;

        if (panel != null)
        {
            panel.SetActive(true);
        }

        if (shopNameText != null)
        {
            string title = catalog != null && !string.IsNullOrWhiteSpace(catalog.shopName)
                ? catalog.shopName
                : "Shop";
            shopNameText.text = title;
        }

        SetMessage(string.Empty);
        RefreshMoney();
        BuildList();

        if (refreshScrollRoutine != null)
        {
            StopCoroutine(refreshScrollRoutine);
        }

        refreshScrollRoutine = StartCoroutine(RefreshScrollNextFrame());
    }

    public void Hide()
    {
        currentCatalog = null;
        SetMessage(string.Empty);

        if (panel != null && panel != gameObject)
        {
            panel.SetActive(false);
        }
        else if (panel == gameObject)
        {
            gameObject.SetActive(false);
        }
    }

    public void TryBuy(ShopItemEntry entry)
    {
        if (entry == null || entry.item == null)
        {
            SetMessage("Item kh�ng h?p l?.");
            return;
        }

        int price = Mathf.Max(0, entry.price);
        int amount = Mathf.Max(1, entry.amount);

        var stats = StatManager.Instance;
        if (stats == null)
        {
            SetMessage("Kh�ng t�m th?y StatManager.");
            return;
        }

        if (stats.money < price)
        {
            SetMessage("Kh�ng ?? ti?n.");
            return;
        }

        var inv = InventorySystem.Instance;
        if (inv == null)
        {
            SetMessage("Kh�ng t�m th?y InventorySystem.");
            return;
        }

        if (!inv.CanAddItem(entry.item, amount))
        {
            SetMessage("Inventory ??y.");
            return;
        }

        bool added = inv.TryAddItem(entry.item, amount);
        if (!added)
        {
            SetMessage("Kh�ng th? mua (Inventory ??y).");
            return;
        }

        stats.money -= price;
        if (stats.money < 0f) stats.money = 0f;

        if (EventManager.Instance != null)
        {
            EventManager.Instance.NotifyStatChanged();
        }

        SetMessage($"?� mua {entry.item.itemName} x{amount}.");
        RefreshMoney();
    }

    private void BuildList()
    {
        if (itemsRoot == null || itemRowPrefab == null) return;

        for (int i = itemsRoot.childCount - 1; i >= 0; i--)
        {
            Destroy(itemsRoot.GetChild(i).gameObject);
        }

        if (currentCatalog == null || currentCatalog.items == null) return;

        for (int i = 0; i < currentCatalog.items.Count; i++)
        {
            ShopItemEntry entry = currentCatalog.items[i];
            if (entry == null || entry.item == null) continue;

            GameObject go = Instantiate(itemRowPrefab, itemsRoot);
            var row = go.GetComponent<ShopItemRowUI>();
            if (row != null)
            {
                row.Setup(entry, this);
            }
        }

        // Layout will be rebuilt in RefreshScrollNextFrame() after Unity has processed the new objects.
    }

    private System.Collections.IEnumerator RefreshScrollNextFrame()
    {
        yield return null;

        var content = itemsRoot as RectTransform;

        if (scrollRect != null && content != null)
        {
            if (scrollRect.content != content)
            {
                scrollRect.content = content;
            }

            Canvas.ForceUpdateCanvases();
            LayoutRebuilder.ForceRebuildLayoutImmediate(content);
            Canvas.ForceUpdateCanvases();

            scrollRect.verticalNormalizedPosition = 1f;
        }

        refreshScrollRoutine = null;
    }

    private void RefreshMoney()
    {
        if (moneyText == null) return;

        var stats = StatManager.Instance;
        if (stats == null) return;

        moneyText.text = $"Money: {stats.money:0}";
    }

    private void SetMessage(string text)
    {
        if (messageText != null)
        {
            messageText.text = text ?? string.Empty;
        }
    }
}
