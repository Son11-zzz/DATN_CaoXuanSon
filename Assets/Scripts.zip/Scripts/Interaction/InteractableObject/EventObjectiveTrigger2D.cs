using UnityEngine;


[RequireComponent(typeof(Collider2D))]
public class EventObjectiveTrigger2D : MonoBehaviour
{
    [Header("Event Objective")]
    [SerializeField] private string objectiveId;

    [Header("Time Window (optional)")]
    [SerializeField] private bool requireTimeWindow;
    [SerializeField] private int startHour = 7;
    [SerializeField] private int endHourExclusive = 9;
    [SerializeField, TextArea] private string tooEarlyText = "You are too early.";
    [SerializeField, TextArea] private string tooLateText = "You are late.";

    [Header("On Complete: Time Skip (optional)")]
    [SerializeField] private bool fadeAndSkipTimeOnComplete;
    [SerializeField] private int targetHour = 12;
    [SerializeField] private float fadeOutDuration = 0.3f;
    [SerializeField] private float holdDuration = 0.2f;
    [SerializeField] private float fadeInDuration = 0.3f;

    [Header("Behavior")]
    [SerializeField] private bool oneShot = true;

    [Header("Dialogue")]
    [SerializeField] private bool showDialogueOnFail = true;
    [SerializeField] private string okText = "OK";

    private bool fired;

    private void Reset()
    {
        var col = GetComponent<Collider2D>();
        if (col != null)
        {
            col.isTrigger = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (oneShot && fired) return;
        if (!other.CompareTag("Player")) return;

        if (StoryEventManager.Instance == null) return;
        if (string.IsNullOrWhiteSpace(objectiveId)) return;

        bool isLate;
        if (!CheckTimeWindow(out string failMessage, out isLate))
        {
            if (showDialogueOnFail)
            {
                ShowInfoDialogue(failMessage);
            }

            return;
        }

        // If the player is late, still allow completing the objective, but apply late penalty now.
        if (isLate)
        {
            StoryEventManager.Instance.ApplyLatePenaltyNow();
        }

        bool ok = StoryEventManager.Instance.TryCompleteObjective(objectiveId.Trim(), out string reason);
        if (!ok)
        {
            if (showDialogueOnFail)
            {
                ShowInfoDialogue(string.IsNullOrWhiteSpace(reason) ? "Can't do that right now." : reason);
            }

            return;
        }

        fired = true;

        if (fadeAndSkipTimeOnComplete)
        {
            var fader = ResolveScreenFader();
            if (fader != null)
            {
                fader.FadeWithMidAction(SkipToTargetHour, fadeOutDuration, holdDuration, fadeInDuration);
            }
            else
            {
                SkipToTargetHour();
            }
        }
    }

    private bool CheckTimeWindow(out string failMessage, out bool isLate)
    {
        failMessage = null;
        isLate = false;

        if (!requireTimeWindow) return true;
        if (GameTimeManager.Instance == null) return true;

        int h = GameTimeManager.Instance.Hour;
        int start = Mathf.Clamp(startHour, 0, 23);
        int end = Mathf.Clamp(endHourExclusive, 0, 24);
        if (end <= start) end = start + 1;

        if (h < start)
        {
            failMessage = tooEarlyText;
            return false;
        }

        if (h >= end)
        {
            // Late is allowed: we will complete the objective but apply a late penalty.
            isLate = true;
        }

        return true;
    }

    private void SkipToTargetHour()
    {
        if (GameTimeManager.Instance == null) return;

        int sem = GameTimeManager.Instance.Semester;
        int day = GameTimeManager.Instance.DayInSemester;
        int h = Mathf.Clamp(targetHour, 0, 23);
        GameTimeManager.Instance.SetTime(sem, day, h);
    }

    private void ShowInfoDialogue(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;

        var ds = ResolveDialogueSystem();
        if (ds == null || ds.IsDialogueActive) return;

        string ok = string.IsNullOrWhiteSpace(okText) ? "OK" : okText;

        var data = ScriptableObject.CreateInstance<DialogueData>();
        data.lines = new System.Collections.Generic.List<DialogueLine>(1)
        {
            new DialogueLine
            {
                text = text,
                choices = new System.Collections.Generic.List<DialogueChoice>(1)
                {
                    new DialogueChoice { choiceText = ok, type = ChoiceType.End }
                }
            }
        };

        ds.StartDialogue(data, null, _ =>
        {
            Destroy(data);
            return true;
        });
    }

    private static DialogueSystem ResolveDialogueSystem()
    {
        if (DialogueSystem.Instance != null) return DialogueSystem.Instance;

        var systems = Object.FindObjectsByType<DialogueSystem>(FindObjectsInactive.Include);
        return systems != null && systems.Length > 0 ? systems[0] : null;
    }

    private static ScreenFader ResolveScreenFader()
    {
        var faders = Object.FindObjectsByType<ScreenFader>(FindObjectsInactive.Include);
        return faders != null && faders.Length > 0 ? faders[0] : null;
    }
}
