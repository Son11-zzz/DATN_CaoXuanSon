using System;
using System.Collections.Generic;
using UnityEngine;

public class StoryEventManager : MonoBehaviour
{
    public static StoryEventManager Instance;

    [Header("Config")]
    [SerializeField] private List<StoryEventDefinition> events = new List<StoryEventDefinition>();

    public StoryEventDefinition ActiveEvent { get; private set; }
    public bool IsEventActive => ActiveEvent != null;
    public bool IsActiveEventComplete => ActiveEvent != null && IsEventComplete(ActiveEvent);

    public event Action<StoryEventDefinition> OnEventStarted;
    public event Action<StoryEventDefinition> OnEventCompleted;
    public event Action OnProgressChanged;
    public event Action<string> OnObjectiveCompleted;

    private readonly HashSet<string> completedObjectiveIds = new HashSet<string>(StringComparer.Ordinal);
    private bool latePenaltyApplied;
    private bool missApplied;

    private bool lateDialoguePending;
    private DialogueData lateDialogueRuntime;
    private StoryEventDefinition lateDialogueSource;

    private bool startLetterShown;
    private bool startDialogueShown;

    // Prevent the same event from being started again later in the same day.
    private readonly HashSet<StoryEventDefinition> triggeredEventsToday = new HashSet<StoryEventDefinition>();
    private int lastTrackedSemester = -1;
    private int lastTrackedDay = -1;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        if (transform.parent != null)
        {
            transform.SetParent(null);
        }

        DontDestroyOnLoad(gameObject);
    }

    private void OnEnable()
    {
        if (GameTimeManager.Instance != null)
        {
            GameTimeManager.Instance.OnTimeChanged += HandleTimeChanged;
        }
    }

    private void OnDisable()
    {
        if (GameTimeManager.Instance != null)
        {
            GameTimeManager.Instance.OnTimeChanged -= HandleTimeChanged;
        }
    }

    private void Start()
    {
        TryStartEventForCurrentTime();
    }

    private void HandleTimeChanged()
    {
        TryStartEventForCurrentTime();
    }

    private void TryStartEventForCurrentTime()
    {
        if (GameTimeManager.Instance == null) return;
        if (ActiveEvent != null) return;

        int sem = GameTimeManager.Instance.Semester;
        int day = GameTimeManager.Instance.DayInSemester;

        if (sem != lastTrackedSemester || day != lastTrackedDay)
        {
            triggeredEventsToday.Clear();
            lastTrackedSemester = sem;
            lastTrackedDay = day;
        }

        StoryEventDefinition match = null;
        for (int i = 0; i < events.Count; i++)
        {
            var e = events[i];
            if (e == null) continue;
            if (e.Matches(sem, day))
            {
                if (triggeredEventsToday.Contains(e))
                {
                    continue;
                }

                match = e;
                break;
            }
        }

        if (match == null) return;

        StartEvent(match);
    }

    private void StartEvent(StoryEventDefinition ev)
    {
        ActiveEvent = ev;
        if (ev != null)
        {
            triggeredEventsToday.Add(ev);
        }
        completedObjectiveIds.Clear();
        latePenaltyApplied = false;
        missApplied = false;
        lateDialoguePending = false;
        lateDialogueSource = null;
        CleanupLateRuntimeDialogue();
        startLetterShown = false;
        startDialogueShown = false;

        if (ev != null && ev.lockAutoTimeUntilComplete && GameTimeManager.Instance != null)
        {
            GameTimeManager.Instance.SetAutoTickEnabled(false);
        }

        // Try to show the start letter immediately if the UI scene is already loaded.
        // If it's not yet loaded, we'll retry in Update().
        TryShowStartIntro();

        OnEventStarted?.Invoke(ev);
        OnProgressChanged?.Invoke();
    }

    private void TryShowStartIntro()
    {
        if (ActiveEvent == null) return;

        // 1) Prefer letter
        if (!startLetterShown && ActiveEvent.showLetterOnStart)
        {
            if (TryShowStartLetter(ActiveEvent))
            {
                startLetterShown = true;
                return;
            }
        }

        // 2) Fallback to dialogue
        if (!startDialogueShown && ActiveEvent.startDialogue != null)
        {
            var ds = ResolveDialogueSystem();
            if (ds != null && !ds.IsDialogueActive)
            {
                startDialogueShown = true;
                ds.StartDialogue(ActiveEvent.startDialogue, null);
            }
        }
    }

    private static bool TryShowStartLetter(StoryEventDefinition ev)
    {
        if (ev == null) return false;
        if (!ev.showLetterOnStart) return false;

        var ui = ResolveEventLetterUI();
        if (ui == null || ui.IsOpen) return false;

        ui.gameObject.SetActive(true);
        ui.Show(ev, () =>
        {
            if (ev.startDialogue != null)
            {
                var ds = ResolveDialogueSystem();
                if (ds != null && !ds.IsDialogueActive)
                {
                    ds.StartDialogue(ev.startDialogue, null);
                }
            }
        });

        return true;
    }

    private static EventLetterUI ResolveEventLetterUI()
    {
        if (EventLetterUI.Instance != null) return EventLetterUI.Instance;

        var uis = UnityEngine.Object.FindObjectsByType<EventLetterUI>(FindObjectsInactive.Include);
        return uis != null && uis.Length > 0 ? uis[0] : null;
    }

    public bool TryCompleteObjective(string objectiveId)
    {
        return TryCompleteObjective(objectiveId, out _);
    }

    public bool TryCompleteObjective(string objectiveId, out string reason)
    {
        reason = null;

        if (objectiveId != null)
        {
            objectiveId = objectiveId.Trim();
        }

        if (!CanCompleteObjective(objectiveId, out reason))
        {
            return false;
        }

        if (!completedObjectiveIds.Add(objectiveId))
        {
            reason = "Objective already completed.";
            return false;
        }

        OnObjectiveCompleted?.Invoke(objectiveId);
        OnProgressChanged?.Invoke();

        if (IsEventComplete(ActiveEvent))
        {
            CompleteActiveEvent();
        }

        return true;
    }

    public bool CanCompleteObjective(string objectiveId, out string reason)
    {
        reason = null;

        if (objectiveId != null)
        {
            objectiveId = objectiveId.Trim();
        }

        if (string.IsNullOrWhiteSpace(objectiveId))
        {
            reason = "Objective id is empty.";
            return false;
        }

        if (ActiveEvent == null)
        {
            reason = "No active event.";
            return false;
        }

        if (!HasObjective(ActiveEvent, objectiveId))
        {
            reason = $"Objective '{objectiveId}' is not part of active event '{ActiveEvent.name}'. Available: {BuildObjectiveIdList(ActiveEvent)}";
            return false;
        }

        if (!TryGetObjectivePrerequisite(ActiveEvent, objectiveId, out string prerequisiteId))
        {
            // objective not found (shouldn't happen because HasObjective checked)
            return true;
        }

        if (!string.IsNullOrWhiteSpace(prerequisiteId) && !IsObjectiveComplete(prerequisiteId))
        {
            reason = $"Locked. Complete '{prerequisiteId}' first.";
            return false;
        }

        return true;
    }

    private static string BuildObjectiveIdList(StoryEventDefinition ev)
    {
        if (ev == null || ev.objectives == null || ev.objectives.Count == 0) return "(none)";

        var ids = new List<string>(ev.objectives.Count);
        for (int i = 0; i < ev.objectives.Count; i++)
        {
            var o = ev.objectives[i];
            if (o == null) continue;
            if (string.IsNullOrWhiteSpace(o.id)) continue;
            ids.Add(o.id.Trim());
        }

        if (ids.Count == 0) return "(none)";
        return string.Join(", ", ids);
    }

    private static bool TryGetObjectivePrerequisite(StoryEventDefinition ev, string objectiveId, out string prerequisiteId)
    {
        prerequisiteId = null;
        if (ev == null || ev.objectives == null) return false;

        for (int i = 0; i < ev.objectives.Count; i++)
        {
            var o = ev.objectives[i];
            if (o == null) continue;
            if (!string.Equals(o.id, objectiveId, StringComparison.Ordinal)) continue;

            prerequisiteId = o.unlockAfterObjectiveId;
            return true;
        }

        return false;
    }

    public bool IsObjectiveComplete(string objectiveId)
    {
        if (string.IsNullOrWhiteSpace(objectiveId)) return false;
        return completedObjectiveIds.Contains(objectiveId);
    }

    private void CompleteActiveEvent()
    {
        var ev = ActiveEvent;

        if (ev != null && ev.resumeAutoTimeWhenComplete && GameTimeManager.Instance != null)
        {
            GameTimeManager.Instance.SetAutoTickEnabled(true);
        }

        ActiveEvent = null;

        if (ev != null && ev.completedDialogue != null)
        {
            var ds = ResolveDialogueSystem();
            if (ds != null && !ds.IsDialogueActive)
            {
                ds.StartDialogue(ev.completedDialogue, null);
            }
        }

        OnEventCompleted?.Invoke(ev);
        OnProgressChanged?.Invoke();
    }

    private void Update()
    {
        // Retry showing the letter/dialogue after UI scenes are loaded.
        // This is important on boot because gameplay UI is often loaded additively a frame later.
        TryShowStartIntro();

        TryShowLateDialogueIfPending();

        TryApplyLatePenalty();
        TryFailByMissDeadline();
    }

    private void TryApplyLatePenalty()
    {
        if (latePenaltyApplied) return;
        if (ActiveEvent == null) return;
        if (!ActiveEvent.applyLatePenalty) return;

        if (GameTimeManager.Instance == null) return;
        if (StatManager.Instance == null) return;

        if (!string.IsNullOrWhiteSpace(ActiveEvent.lateObjectiveId) && IsObjectiveComplete(ActiveEvent.lateObjectiveId))
        {
            latePenaltyApplied = true;
            return;
        }

        if (GameTimeManager.Instance.Hour < ActiveEvent.lateHour) return;

        ApplyLatePenaltyInternal();
    }

    public bool ApplyLatePenaltyNow()
    {
        if (latePenaltyApplied) return false;
        if (ActiveEvent == null) return false;
        if (!ActiveEvent.applyLatePenalty) return false;
        if (StatManager.Instance == null) return false;

        ApplyLatePenaltyInternal();
        return true;
    }

    private void ApplyLatePenaltyInternal()
    {
        if (ActiveEvent == null) return;
        if (StatManager.Instance == null) return;

        lateDialogueSource = ActiveEvent;

        float energyPenalty = Mathf.Max(0f, ActiveEvent.lateEnergyPenalty);
        float stressPenalty = Mathf.Max(0f, ActiveEvent.lateStressPenalty);

        if (energyPenalty > 0f)
        {
            StatManager.Instance.energy = Mathf.Max(0f, StatManager.Instance.energy - energyPenalty);
        }

        if (stressPenalty > 0f)
        {
            StatManager.Instance.stress += stressPenalty;
        }

        latePenaltyApplied = true;

        // Show a one-time late notification.
        lateDialoguePending = true;

        if (EventManager.Instance != null)
        {
            EventManager.Instance.NotifyStatChanged();
        }
    }

    private void TryShowLateDialogueIfPending()
    {
        if (!lateDialoguePending) return;
        var source = ActiveEvent != null ? ActiveEvent : lateDialogueSource;
        if (source == null)
        {
            lateDialoguePending = false;
            CleanupLateRuntimeDialogue();
            return;
        }

        var ds = ResolveDialogueSystem();
        if (ds == null) return;
        if (ds.IsDialogueActive) return;

        DialogueData dataToShow = source.lateDialogue;
        if (dataToShow == null)
        {
            if (lateDialogueRuntime == null)
            {
                string ok = string.IsNullOrWhiteSpace(source.lateOkText) ? "OK" : source.lateOkText;
                string msg = string.IsNullOrWhiteSpace(source.lateMessage) ? "You are late." : source.lateMessage;
                lateDialogueRuntime = CreateOneLineDialogue(msg, ok);
            }

            dataToShow = lateDialogueRuntime;
        }

        // Use external handler to cleanup the runtime dialogue when closed.
        ds.StartDialogue(dataToShow, null, _ =>
        {
            lateDialoguePending = false;
            lateDialogueSource = null;
            CleanupLateRuntimeDialogue();
            return true;
        });
    }

    private static DialogueData CreateOneLineDialogue(string text, string okText)
    {
        var data = ScriptableObject.CreateInstance<DialogueData>();
        data.lines = new List<DialogueLine>(1)
        {
            new DialogueLine
            {
                text = text,
                choices = new List<DialogueChoice>(1)
                {
                    new DialogueChoice { choiceText = okText, type = ChoiceType.End }
                }
            }
        };

        return data;
    }

    private void CleanupLateRuntimeDialogue()
    {
        if (lateDialogueRuntime != null)
        {
            Destroy(lateDialogueRuntime);
            lateDialogueRuntime = null;
        }
    }

    private void TryFailByMissDeadline()
    {
        if (missApplied) return;
        if (ActiveEvent == null) return;
        if (!ActiveEvent.failIfMissed) return;

        if (GameTimeManager.Instance == null) return;

        if (GameTimeManager.Instance.Hour < ActiveEvent.missHour) return;

        if (!string.IsNullOrWhiteSpace(ActiveEvent.missObjectiveId) && IsObjectiveComplete(ActiveEvent.missObjectiveId))
        {
            missApplied = true;
            return;
        }

        FailActiveEventInternal(ActiveEvent);
        missApplied = true;
    }

    public bool FailActiveEvent()
    {
        if (ActiveEvent == null) return false;
        FailActiveEventInternal(ActiveEvent);
        missApplied = true;
        return true;
    }

    private void FailActiveEventInternal(StoryEventDefinition ev)
    {
        if (ev == null) return;

        if (StatManager.Instance != null)
        {
            float energyPenalty = Mathf.Max(0f, ev.missEnergyPenalty);
            float stressPenalty = Mathf.Max(0f, ev.missStressPenalty);
            float gpaPenalty = Mathf.Max(0f, ev.missGpaPenalty);

            if (energyPenalty > 0f)
            {
                StatManager.Instance.energy = Mathf.Max(0f, StatManager.Instance.energy - energyPenalty);
            }

            if (stressPenalty > 0f)
            {
                StatManager.Instance.stress += stressPenalty;
            }

            if (gpaPenalty > 0f)
            {
                StatManager.Instance.gpa = Mathf.Max(0f, StatManager.Instance.gpa - gpaPenalty);
            }
        }

        if (ev.resumeAutoTimeWhenComplete && GameTimeManager.Instance != null)
        {
            GameTimeManager.Instance.SetAutoTickEnabled(true);
        }

        ActiveEvent = null;

        if (ev.missedDialogue != null)
        {
            var ds = ResolveDialogueSystem();
            if (ds != null && !ds.IsDialogueActive)
            {
                ds.StartDialogue(ev.missedDialogue, null);
            }
        }

        if (EventManager.Instance != null)
        {
            EventManager.Instance.NotifyStatChanged();
        }

        OnEventCompleted?.Invoke(ev);
        OnProgressChanged?.Invoke();
    }

    private static bool HasObjective(StoryEventDefinition ev, string objectiveId)
    {
        if (ev == null || ev.objectives == null) return false;

        for (int i = 0; i < ev.objectives.Count; i++)
        {
            if (ev.objectives[i] == null) continue;
            if (string.Equals(ev.objectives[i].id, objectiveId, StringComparison.Ordinal))
            {
                return true;
            }
        }

        return false;
    }

    private bool IsEventComplete(StoryEventDefinition ev)
    {
        if (ev == null || ev.objectives == null || ev.objectives.Count == 0) return true;

        for (int i = 0; i < ev.objectives.Count; i++)
        {
            var o = ev.objectives[i];
            if (o == null) continue;

            if (string.IsNullOrWhiteSpace(o.id)) continue;
            if (!completedObjectiveIds.Contains(o.id)) return false;
        }

        return true;
    }

    private static DialogueSystem ResolveDialogueSystem()
    {
        if (DialogueSystem.Instance != null) return DialogueSystem.Instance;

        var systems = UnityEngine.Object.FindObjectsByType<DialogueSystem>(FindObjectsInactive.Include);
        return systems != null && systems.Length > 0 ? systems[0] : null;
    }
}
