using UnityEngine;

public class StatManager : MonoBehaviour
{
    public static StatManager Instance;

    [Header("Timeline")]
    public int day = 1;
    public int time = 8;

    [Header("Stats")]
    public float gpa;
    public float stress;
    public float money;
    public float health;
    public float energy;
    public float social;
    public float skill;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        if (transform.parent != null)
        {
            transform.SetParent(null);
        }

        DontDestroyOnLoad(gameObject);  
    }

    private void Start()
    {
        if (EventManager.Instance != null)
        {
            EventManager.Instance.OnChoiceSelected += UpdateStat;
            // Delay 1 frame to ensure UI objects have run OnEnable/Start and subscribed.
            Invoke(nameof(NotifyInitialStats), 0f);
        }
    }

    private void OnEnable()
    {
        if (EventManager.Instance != null)
        {
            Invoke(nameof(NotifyInitialStats), 0f);
        }
    }

    private void NotifyInitialStats()
    {
        if (EventManager.Instance != null)
        {
            EventManager.Instance.NotifyStatChanged();
        }
    }

    void UpdateStat()
    {
        gpa += 0.1f;
        stress -= 1f;

        energy -= 1f;
        if (energy < 0f) energy = 0f;

        time += 1;
        if (time >= 24)
        {
            time = 0;
            day += 1;
        }

        EventManager.Instance.NotifyStatChanged();
    }
}
