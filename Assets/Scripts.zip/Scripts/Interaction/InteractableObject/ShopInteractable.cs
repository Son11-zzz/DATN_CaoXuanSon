using UnityEngine;

public class ShopInteractable : InteractableBase
{
    [Header("Shop")]
    [SerializeField] private ShopCatalog catalog;

    public override void Interact()
    {
        if (catalog == null)
        {
            Debug.LogWarning($"ShopInteractable '{name}': catalog is null.");
            return;
        }

        var ui = ResolveShopUI();
        if (ui == null)
        {
            Debug.LogWarning("ShopInteractable: ShopUI not found in loaded scenes.");
            return;
        }

        ui.gameObject.SetActive(true);
        ui.Show(catalog);
    }

    private static ShopUI ResolveShopUI()
    {
        if (ShopUI.Instance != null) return ShopUI.Instance;

        var uis = Object.FindObjectsByType<ShopUI>(FindObjectsInactive.Include);
        return uis != null && uis.Length > 0 ? uis[0] : null;
    }

    public override string GetInteractText()
    {
        return "Press E";
    }
}
