using UnityEngine;

public class StudyDeskInteractable : InteractableBase
{
    [Header("Study")]
    [SerializeField] private float gpaGain = 0.1f;
    [SerializeField] private float stressGain;
    [SerializeField] private float energyCost = 1f;
    [SerializeField] private int hoursToAdvance = 1;

    public override void Interact()
    {
        var stats = StatManager.Instance;
        if (stats != null)
        {
            stats.gpa += gpaGain;
            stats.stress += stressGain;
            stats.energy = Mathf.Max(0f, stats.energy - Mathf.Max(0f, energyCost));
        }

        if (GameTimeManager.Instance != null)
        {
            int h = Mathf.Max(0, hoursToAdvance);
            if (h > 0)
            {
                GameTimeManager.Instance.AdvanceHours(h);
            }
            else
            {
                // still notify UI
                GameTimeManager.Instance.SetTime(GameTimeManager.Instance.Semester, GameTimeManager.Instance.DayInSemester, GameTimeManager.Instance.Hour);
            }
        }

        if (EventManager.Instance != null)
        {
            EventManager.Instance.NotifyStatChanged();
        }
    }

    public override string GetInteractText()
    {
        return "Press E";
    }
}
