using System.Collections.Generic;
using UnityEngine;

public class BedSleepInteractable : InteractableBase
{
    [Header("Sleep")]
    [SerializeField] private int wakeHour = 8;

    [Header("Event Lock Message")]
    [SerializeField, TextArea] private string lockedText = "You can't sleep yet.";

    public override void Interact()
    {
        if (GameTimeManager.Instance == null)
        {
            Debug.LogWarning("BedSleepInteractable: GameTimeManager.Instance is null.");
            return;
        }

        if (StoryEventManager.Instance != null && StoryEventManager.Instance.IsEventActive && !StoryEventManager.Instance.IsActiveEventComplete)
        {
            var ev = StoryEventManager.Instance.ActiveEvent;
            if (ev != null && ev.blockSleepUntilComplete)
            {
                ShowLockedDialogue();
                return;
            }

            if (ev != null && ev.failEventIfDayEndsIncomplete)
            {
                StoryEventManager.Instance.FailActiveEvent();
            }
        }

        int sem = GameTimeManager.Instance.Semester;
        int day = GameTimeManager.Instance.DayInSemester;

        GameTimeManager.Instance.SetTime(sem, day + 1, Mathf.Clamp(wakeHour, 0, 23));

        if (EventManager.Instance != null)
        {
            EventManager.Instance.NotifyStatChanged();
        }
    }

    private void ShowLockedDialogue()
    {
        var ds = ResolveDialogueSystem();
        if (ds == null || ds.IsDialogueActive) return;

        var data = ScriptableObject.CreateInstance<DialogueData>();
        data.lines = new List<DialogueLine>(1)
        {
            new DialogueLine
            {
                text = lockedText,
                choices = new List<DialogueChoice>(1)
                {
                    new DialogueChoice { choiceText = "OK", type = ChoiceType.End }
                }
            }
        };

        ds.StartDialogue(data, null, _ =>
        {
            Destroy(data);
            return true;
        });
    }

    private static DialogueSystem ResolveDialogueSystem()
    {
        if (DialogueSystem.Instance != null) return DialogueSystem.Instance;

        var systems = Object.FindObjectsByType<DialogueSystem>(FindObjectsInactive.Include);
        return systems != null && systems.Length > 0 ? systems[0] : null;
    }
}
