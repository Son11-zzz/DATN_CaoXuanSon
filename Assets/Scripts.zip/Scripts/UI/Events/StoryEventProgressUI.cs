using System.Text;
using TMPro;
using UnityEngine;

public class StoryEventProgressUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private TextMeshProUGUI objectivesText;
    [SerializeField] private GameObject root;

    private void Awake()
    {
        // If root is assigned, it will be shown/hidden based on whether an event is active.
    }

    private void OnEnable()
    {
        Subscribe();
        Refresh();
    }

    private void OnDisable()
    {
        Unsubscribe();
    }

    private void Update()
    {
        // In case this UI is enabled before StoryEventManager exists.
        Subscribe();
    }

    private void Subscribe()
    {
        if (StoryEventManager.Instance == null) return;

        StoryEventManager.Instance.OnProgressChanged -= Refresh;
        StoryEventManager.Instance.OnProgressChanged += Refresh;
    }

    private void Unsubscribe()
    {
        if (StoryEventManager.Instance == null) return;

        StoryEventManager.Instance.OnProgressChanged -= Refresh;
    }

    private void Refresh()
    {
        var mgr = StoryEventManager.Instance;
        if (mgr == null || mgr.ActiveEvent == null)
        {
            SetActive(false);
            return;
        }

        SetActive(true);

        var ev = mgr.ActiveEvent;

        if (titleText != null)
        {
            titleText.text = $"Event: {ev.name}";
        }

        if (objectivesText != null)
        {
            objectivesText.text = BuildObjectivesText(ev, mgr);
        }
    }

    private string BuildObjectivesText(StoryEventDefinition ev, StoryEventManager mgr)
    {
        if (ev == null || ev.objectives == null || ev.objectives.Count == 0)
        {
            return "";
        }

        var sb = new StringBuilder(256);
        for (int i = 0; i < ev.objectives.Count; i++)
        {
            var o = ev.objectives[i];
            if (o == null) continue;

            if (!string.IsNullOrWhiteSpace(o.unlockAfterObjectiveId) && !mgr.IsObjectiveComplete(o.unlockAfterObjectiveId))
            {
                continue;
            }

            string id = o.id;
            bool complete = !string.IsNullOrWhiteSpace(id) && mgr.IsObjectiveComplete(id);

            sb.Append(complete ? "[x] " : "[ ] ");

            if (!string.IsNullOrWhiteSpace(o.description))
            {
                sb.Append(o.description);
            }
            else if (!string.IsNullOrWhiteSpace(id))
            {
                sb.Append(id);
            }

            if (i < ev.objectives.Count - 1)
            {
                sb.AppendLine();
            }
        }

        return sb.ToString();
    }

    private void SetActive(bool active)
    {
        if (root != null)
        {
            root.SetActive(active);
        }
    }
}
