using System;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class QuestPanelUI : MonoBehaviour
{
    [Header("Root")]
    [SerializeField] private GameObject panelRoot;

    [Header("Visibility (Optional)")]
    [SerializeField] private CanvasGroup canvasGroup;
    [SerializeField] private bool useCanvasGroupIfAvailable = true;

    [Header("UI")]
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private TextMeshProUGUI bodyText;
    [SerializeField] private ScrollRect scrollRect;

    [Header("Behavior")]
    [SerializeField] private bool showCompletedInBody = false;
    [SerializeField] private bool showOnlyFirstQuest = true;
    [SerializeField] private bool resetScrollOnRefresh = true;

    private string lastTitle = "Quest";
    private string lastBody = "No active quests";

    private bool subscribed = false;
    private bool isVisible;

    [Header("Debug")]
    [SerializeField] private bool logToggle = false;

    private void Awake()
    {
        if (panelRoot == null)
        {
            panelRoot = gameObject;
        }

        if (canvasGroup == null && panelRoot != null)
        {
            canvasGroup = panelRoot.GetComponent<CanvasGroup>();
        }

        // Default hidden
        SetVisible(false);
    }

    private void OnEnable()
    {
        TrySubscribe();
        Refresh();
    }

    private void OnDisable()
    {
        Unsubscribe();
    }

    private void Update()
    {
        TrySubscribe();
    }

    public void Toggle()
    {
        SetVisible(!isVisible);

        if (logToggle && panelRoot != null)
        {
            Debug.Log($"QuestPanelUI: Toggle '{panelRoot.name}' visible={isVisible}", panelRoot);
        }

        if (isVisible)
        {
            Refresh();
        }
    }

    public bool IsVisible()
    {
        return isVisible;
    }

    public void Show()
    {
        SetVisible(true);
        Refresh();
    }

    public void Hide()
    {
        SetVisible(false);
    }

    private void SetVisible(bool visible)
    {
        isVisible = visible;

        if (panelRoot == null) return;

        bool canUseCanvasGroup = useCanvasGroupIfAvailable && canvasGroup != null;

        if (canUseCanvasGroup)
        {
            canvasGroup.alpha = visible ? 1f : 0f;
            canvasGroup.blocksRaycasts = visible;
            canvasGroup.interactable = visible;

            // Keep object active so input scripts don't die
            if (!panelRoot.activeSelf)
            {
                panelRoot.SetActive(true);
            }

            return;
        }

        panelRoot.SetActive(visible);
    }

    #region Event Subscription

    private void TrySubscribe()
    {
        if (subscribed) return;

        bool didSubscribe = false;

        if (QuestManager.Instance != null)
        {
            QuestManager.Instance.OnQuestUpdated -= Refresh;
            QuestManager.Instance.OnQuestUpdated += Refresh;
            didSubscribe = true;
        }

        if (InventorySystem.Instance != null)
        {
            InventorySystem.Instance.OnInventoryChanged -= Refresh;
            InventorySystem.Instance.OnInventoryChanged += Refresh;
            didSubscribe = true;
        }

        subscribed = didSubscribe;
    }

    private void Unsubscribe()
    {
        if (QuestManager.Instance != null)
        {
            QuestManager.Instance.OnQuestUpdated -= Refresh;
        }

        if (InventorySystem.Instance != null)
        {
            InventorySystem.Instance.OnInventoryChanged -= Refresh;
        }

        subscribed = false;
    }

    #endregion

    #region UI Refresh

    public void Refresh()
    {
        _ = showCompletedInBody;
        var qm = QuestManager.Instance;

        if (qm == null)
        {
            SetTexts(lastTitle, lastBody);
            return;
        }

        var quests = qm.ActiveQuests;

        // No active quests
        if (quests == null || quests.Count == 0)
        {
            SetTexts("Quest", "No active quests");
            return;
        }

        int count = showOnlyFirstQuest ? Mathf.Min(1, quests.Count) : quests.Count;

        // Preserve last title to avoid resetting when toggling
        string headerTitle = lastTitle;

        if (quests[0] != null)
        {
            headerTitle = string.IsNullOrWhiteSpace(quests[0].title)
                ? quests[0].GetId()
                : quests[0].title;
        }

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < count; i++)
        {
            var q = quests[i];
            if (q == null) continue;

            bool completed = qm.IsCompleted(q);

            if (showOnlyFirstQuest)
            {
                sb.AppendLine(completed ? "[DONE]" : "[TODO]");
            }
            else
            {
                sb.Append(completed ? "[DONE] " : "[TODO] ");
                sb.AppendLine(string.IsNullOrWhiteSpace(q.title)
                    ? q.GetId()
                    : q.title);
            }

            if (!string.IsNullOrWhiteSpace(q.description))
            {
                sb.AppendLine(q.description);
            }

            if (q.objectives != null)
            {
                foreach (var o in q.objectives)
                {
                    if (o == null || !o.IsValid()) continue;

                    switch (o.type)
                    {
                        case QuestObjectiveType.CollectItem:
                            int have = InventorySystem.Instance != null
                                ? InventorySystem.Instance.GetAmount(o.item)
                                : 0;

                            int need = Mathf.Max(1, o.amount);
                            string itemName = o.item != null
                                ? o.item.itemName
                                : "(missing item)";

                            sb.AppendLine($"- {itemName}: {have}/{need}");
                            break;

                        case QuestObjectiveType.ReachStatValue:
                            sb.AppendLine($"- {o.stat} >= {o.targetValue}");
                            break;

                        case QuestObjectiveType.TalkToNpc:
                            bool talked = qm.HasTalkedToNpc(o.npcId);
                            string npcLabel = string.IsNullOrWhiteSpace(o.npcId)
                                ? "(missing npc)"
                                : o.npcId;
                            sb.AppendLine($"- Talk to {npcLabel}: {(talked ? 1 : 0)}/1");
                            break;
                    }
                }
            }

            if (i < count - 1)
            {
                sb.AppendLine();
            }
        }

        string body = sb.Length > 0
            ? sb.ToString().TrimEnd()
            : "No active quests";

        SetTexts(headerTitle, body);

        if (resetScrollOnRefresh && scrollRect != null)
        {
            scrollRect.normalizedPosition = new Vector2(0f, 1f);
        }
    }

    private void SetTexts(string title, string body)
    {
        lastTitle = title;
        lastBody = body;

        if (titleText != null)
            titleText.text = title;

        if (bodyText != null)
            bodyText.text = body;
    }

    public void RemoveCompletedQuests()
    {
        if (QuestManager.Instance == null) return;

        QuestManager.Instance.RemoveCompletedQuests();
        Refresh();
    }

    public void ResetQuestHUD()
    {
        RemoveCompletedQuests();
    }

    #endregion
}