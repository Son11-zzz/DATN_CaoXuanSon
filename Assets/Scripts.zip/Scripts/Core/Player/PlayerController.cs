﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Vector2 movement;

    [Header("Animation")]
    [SerializeField] private Animator animator;

    private Vector2 lastMoveDir = Vector2.down;

    private bool isMoving;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        if (animator == null)
        {
            animator = GetComponentInChildren<Animator>();
            if (animator == null)
                animator = GetComponent<Animator>();
        }
    }

    void Start()
    {
        // Hướng mặc định khi bắt đầu game
        if (animator != null)
        {
            animator.SetFloat("Horizontal", lastMoveDir.x);
            animator.SetFloat("Vertical", lastMoveDir.y);
            animator.SetFloat("Speed", 0f);
            animator.SetBool("isMoving", false);
        }
    }

    void Update()
    {
        // Nhận input
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        movement = movement.normalized;

        isMoving = movement.sqrMagnitude > 0.01f;

        // Lưu hướng di chuyển cuối cùng
        if (isMoving)
        {
            lastMoveDir = movement;
        }

        // Cập nhật Animator
        if (animator != null)
        {
            Vector2 dir = isMoving ? movement : lastMoveDir;

            animator.SetFloat("Horizontal", dir.x);
            animator.SetFloat("Vertical", dir.y);
            animator.SetFloat("Speed", movement.sqrMagnitude);
            animator.SetBool("isMoving", isMoving);
        }
    }

    void FixedUpdate()
    {
        rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime);
    }
}