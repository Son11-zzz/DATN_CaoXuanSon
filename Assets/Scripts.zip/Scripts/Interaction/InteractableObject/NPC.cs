using UnityEngine;

public class NPC : InteractableBase
{
    public DialogueData dialogueData;

    public override void Interact()
    {
        if (dialogueData == null)
        {
            Debug.LogWarning($"NPC '{name}': dialogueData is null.");
            return;
        }

        var ds = ResolveDialogueSystem();
        if (ds == null)
        {
            Debug.LogWarning($"NPC '{name}': DialogueSystem not found in loaded scenes.");
            return;
        }

        ds.StartDialogue(dialogueData, null);
    }

    private static DialogueSystem ResolveDialogueSystem()
    {
        if (DialogueSystem.Instance != null) return DialogueSystem.Instance;

        var systems = FindObjectsByType<DialogueSystem>(FindObjectsInactive.Include);
        return systems != null && systems.Length > 0 ? systems[0] : null;
    }

    public override string GetInteractText()
    {
        return "Press E";
    }
}