using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "StoryEvent", menuName = "Scriptable Objects/StoryEvent")]
public class StoryEventDefinition : ScriptableObject
{
    [Header("When")]
    [Min(1)] public int semester = 1;
    [Min(1)] public int dayInSemester = 1;

    [Header("Behavior")]
    public bool lockAutoTimeUntilComplete = true;
    public bool resumeAutoTimeWhenComplete = true;

    [Tooltip("If enabled, the bed interaction will be blocked until the event is completed.")]
    public bool blockSleepUntilComplete;

    [Tooltip("If enabled, ending the day (sleeping) while the event is incomplete will fail the event.")]
    public bool failEventIfDayEndsIncomplete = true;

    [Header("Late Penalty")]
    public bool applyLatePenalty;
    [Min(0)] public int lateHour = 7;
    [Tooltip("Only applies the penalty if this objective is not completed yet.")]
    public string lateObjectiveId;
    [Min(0f)] public float lateEnergyPenalty;
    [Min(0f)] public float lateStressPenalty;

    [Header("Late Dialogue")]
    public DialogueData lateDialogue;
    [TextArea] public string lateMessage = "You are late.";
    public string lateOkText = "OK";

    [Header("Miss / Deadline")]
    [Tooltip("If enabled and the objective is not completed by missHour, the event fails (day can continue).")]
    public bool failIfMissed;
    [Min(0)] public int missHour = 12;
    [Tooltip("Fail only if this objective is not completed yet. If empty, fail regardless of objectives.")]
    public string missObjectiveId;
    [Min(0f)] public float missEnergyPenalty;
    [Min(0f)] public float missStressPenalty;
    [Min(0f)] public float missGpaPenalty;
    public DialogueData missedDialogue;

    [Header("Dialogue")]
    public DialogueData startDialogue;
    public DialogueData completedDialogue;

    [Header("Start Letter")]
    public bool showLetterOnStart;
    public string letterTitle;
    [TextArea] public string letterBody;
    public bool includeObjectivesInLetter = true;
    public string letterCloseText = "OK";

    [Header("Objectives")]
    public List<StoryObjective> objectives = new List<StoryObjective>();

    public bool Matches(int currentSemester, int currentDayInSemester)
    {
        return semester == currentSemester && dayInSemester == currentDayInSemester;
    }
}

[Serializable]
public class StoryObjective
{
    public string id;
    [TextArea] public string description;

    [Tooltip("Objective will only be available after this objective id is completed (optional).")]
    public string unlockAfterObjectiveId;
}
