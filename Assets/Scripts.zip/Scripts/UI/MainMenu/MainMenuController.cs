using UnityEngine;

public class MainMenuController : MonoBehaviour
{
    [SerializeField] private string streetSceneName = "22_PlayerHouse";
    [SerializeField] private string streetSpawnId = "Default";

    public void NewGame()
    {
        if (SceneFlowController.Instance == null) return;
        SceneFlowController.Instance.LoadGameplayScene(streetSceneName, streetSpawnId);
    }

    public void ContinueGame()
    {
        // Later: load from SaveManager and call LoadGameplayScene(savedScene, savedSpawnId)
        NewGame();
    }

    public void Quit()
    {
        Application.Quit();
    }
}